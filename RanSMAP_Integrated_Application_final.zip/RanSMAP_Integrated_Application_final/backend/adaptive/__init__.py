"""Adaptive model integration package."""
