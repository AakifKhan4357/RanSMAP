# PS-RanSMAP — Integrated Application

## Project

**Adaptive RanSMAP: An Incremental Learning Framework for Ransomware Detection Using Storage and Memory Access Patterns**

This package contains the integrated RanSMAP frontend and FastAPI backend, baseline research source code, and supporting research documentation.

## Project Structure

- `backend/` — FastAPI application, routes, preprocessing, model services and model assets.
- `frontend/` — HTML, CSS and JavaScript interface.
- `baseline/` — Master baseline research notebook, preprocessing script and baseline-specific README.
- `RESEARCH_DOCUMENTATION.zip` — Supporting research documents covering the research foundation, preprocessing, model and adaptation, validation, experimental results and final evidence.
- `config/` — Application configuration.
- `requirements.txt` — Python dependencies.

## Prerequisites

- Python with compatibility for the required PyTorch version.
- VS Code.
- VS Code Live Server extension.
- Internet access for installing dependencies.

## Setup Instructions

### 1. Extract the ZIP

Extract the final integrated application ZIP.

Open the extracted project folder in VS Code.

### 2. Create a virtual environment

Open the terminal in the project folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Ensure the installed PyTorch version is compatible with the included model artifacts.

### 4. Start the backend

From the project root:

```powershell
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```
Backend:

http://127.0.0.1:8000

API documentation:

http://127.0.0.1:8000/docs

Health endpoint:

http://127.0.0.1:8000/api/health

### 5. Start the frontend

- Open `frontend/index.html` in VS Code.
- Right-click and select **Open with Live Server**.
- Keep Live Server running on port 5500.

The frontend communicates with the backend running on port 8000.

## Included Model Assets

The package includes the model and preprocessing assets currently used by the integrated backend.

These include:

- Feature normalization statistics.
- Baseline model artifact.
- Threshold configuration and threshold-tuned model artifact.

The model artifacts are maintained under `backend/models/` and must remain compatible with the model architecture and preprocessing pipeline implemented in the backend.

## Baseline Research and Documentation

### Baseline Source Code (`baseline/`)

The `baseline/` directory contains the source code and master research notebook associated with the development and evaluation of the RanSMAP baseline CNN-LSTM model.

It includes:

- **Master research notebook (`baseline_master.ipynb`):** Documents dataset inspection, preprocessing validation, data split reconstruction, CNN-LSTM model development, training, evaluation, threshold analysis, and verification of the model artifacts used by the integrated application.
- **Preprocessing script (`ransmap_preprocessing_ready.py`):** Contains the preprocessing implementation used by the baseline research notebook.
- **README (`baseline/README.md`):** Provides information about the baseline research notebook, its purpose, artifact provenance and reproducibility limitations.

The notebook is retained as the research and artifact-provenance record. The integrated application does not execute the notebook at runtime.

### Supporting Research Documentation (`RESEARCH_DOCUMENTATION.zip`)

The `RESEARCH_DOCUMENTATION.zip` archive is maintained at the project root and contains supporting research documents organized into six areas:

1. Research foundation.
2. Preprocessing.
3. Model and adaptation.
4. Validation.
5. Experimental results.
6. Final evidence.

These documents provide supporting information about the project's research methodology, implementation validation, experimental evaluation and evidence.

The baseline notebook and supporting research documents serve as the research reference for understanding the development and evaluation of the model. The integrated application remains the runtime deliverable.

## Current Implementation Status

- Frontend and backend integration completed.
- Application startup confirmed locally.
- Adaptive model initialization confirmed locally.
- Baseline and adaptive prediction workflows are implemented in the application.
- Model comparison interface is implemented.

## Known Limitations

- Actual incremental model weight updates are not yet enabled.
- Feedback is currently accepted in memory and is not persistent across server restarts.
- Final adaptive training and model artifacts are pending.
- Full end-to-end testing and experimental validation are pending.
Do not interpret successful application startup as proof of completed model validation.

## Notes
- The original RanSMAP dataset is not included in this package.
- The Python virtual environment is intentionally excluded.
- Install dependencies separately using `requirements.txt`.
- The baseline research notebook depends on the RanSMAP dataset and Kaggle-specific input paths. Reproducing its execution in another environment requires restoring the necessary dataset and environment.
- The baseline research notebook is provided for research reference and artifact provenance; it is not required to run the integrated application.
- Use the final model artifacts supplied by the model-training team when available.