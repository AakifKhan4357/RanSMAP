#!/usr/bin/env python3
"""
RanSMAP preprocessing pipeline  (Hirano & Kobayashi, Computers & Security 150 (2025) 104202)

Implements Section 4.1 + Appendix D of the paper:
  * every execution folder (6 CSVs) -> one sequence of 23-D feature vectors
        chi = [ chi_s (5 storage features) | chi_m (18 memory features) ]
  * sliding windows: window start t = 0, eps, 2*eps, ... while t <= Td - Twindow
        eps = Twindow, except eps = 1 s when Twindow = 10 s
  * timestamps -> relative time since the first access (per modality by default)

Outputs (in OUT_DIR):
  X_<group>_tw<Twindow>.npy   float32  [N, steps(TD_MAX), 23]   raw (unscaled) features
  meta_<group>.csv            one row per execution (labels, hardware, path, QC)
  split_original.npz          stratified 80/20 train/test indices over group "original"
  config.json                 feature names, class names, window plans
  + load_for_training()       slice Td, pick chi/chi_s/chi_m, standardise on TRAIN only, one-hot

Kaggle:  paste into a cell and run, or:  !python ransmap_preprocess.py
"""
import contextlib
import hashlib
import json
import os
import re
import sys
import time
import zipfile
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import pandas as pd

# ============================== CONFIG ==============================
DATASET_ROOT = "/kaggle/input/datasets/hiranomanabu/ransmap-2024-ransomware-behavioral-features/RanSMAP/dataset"
OUT_DIR = "/kaggle/working/ransmap_processed_v2"
T_WINDOWS = [0.1]                        # paper baseline. Any of [10, 1, 0.1, 0.01] is allowed
TD_MAX = 60                              # seconds stored per execution (paper sweeps Td = 20..60)
TIME_ORIGIN = "per_modality"             # "per_modality" (literal Fig. D.1/D.2) or "common"
N_JOBS = 2                               # conservative for Kaggle
CHUNK_ROWS = 500_000                      # moderate chunk size for memory stability
STRICT = True                            # stop on unexpected dataset/layout problems
VALIDATE_ONLY = False                   # first run checks dataset; set False to start extraction
SPLIT_SEED, TEST_FRACTION = 42, 0.2
EXPECTED = {"original": 1440, "extra": 360, "mix": 100, "variants": 70}
# Verified in both Kaggle's copy and the separately downloaded full dataset.
# Keep this execution, but its two ata-read-derived features are zero placeholders,
# NOT measured zero activity. Metadata explicitly flags the missing source CSV.
KNOWN_MISSING = {
    "original/celeron-gen6/ddr4-2133-16g/LockBit/LockBit-20221006_16-38-01":
    ("ata_read",)
}
# ====================================================================

NS = 1_000_000_000
BASE_NS = NS // 100                      # single-pass resolution 0.01 s (all window sizes are multiples)
GROUPS = ("original", "extra", "mix", "variants")
RANSOM = ["Conti", "Darkside", "LockBit", "REvil", "Ryuk", "WannaCry"]
BENIGN = ["AESCrypt", "Firefox", "Idle", "Office", "SDelete", "Zip"]
CLASSES = RANSOM + BENIGN                # class_id 0..11 (same order as the paper's confusion matrices)
ALIASES = {
    "Conti": ["conti", "bluesky"], "Darkside": ["darkside"], "LockBit": ["lockbit"],
    "REvil": ["revil", "sodinokibi"], "Ryuk": ["ryuk"], "WannaCry": ["wannacry", "wcry"],
    "AESCrypt": ["aescrypt", "aes_crypt", "aes-crypt"], "Firefox": ["firefox"], "Idle": ["idle"],
    "Office": ["office"], "SDelete": ["sdelete"], "Zip": ["zip"],
}
FILE_STEMS = ["ata_read", "ata_write", "mem_read", "mem_write", "mem_readwrite", "mem_exec"]
FEATURE_NAMES = (
    ["T_s_r", "T_s_w", "V_s_r", "V_s_w", "H_s_w"] +
    ["H_m_w", "H_m_rw"] +
    [f"C_{p}_{o}" for p in ("4KB", "2MB", "MMIO") for o in ("r", "w", "rw", "x")] +
    [f"V_m_{o}" for o in ("r", "w", "rw", "x")]
)
FEATURE_SETS = {"chi": slice(0, 23), "chi_s": slice(0, 5), "chi_m": slice(5, 23)}
assert len(FEATURE_NAMES) == 23


# ------------------------- window arithmetic -------------------------
def _ns(sec):
    return int(round(sec * NS))


def window_plan(tw, td):
    """Paper rule: eps = Twindow (eps = 1 s when Twindow = 10 s); window starts while t <= Td - Twindow."""
    tw_ns, td_ns = _ns(tw), _ns(td)
    eps_ns = min(tw_ns, NS)
    assert tw_ns % BASE_NS == 0 and eps_ns % BASE_NS == 0 and tw_ns % eps_ns == 0, f"bad Twindow {tw}"
    return dict(tw=tw, eps_ns=eps_ns, f=eps_ns // BASE_NS, m=tw_ns // eps_ns,
                n_steps=(td_ns - tw_ns) // eps_ns + 1)


def n_steps(tw, td):
    return window_plan(tw, td)["n_steps"]


def tw_tag(tw):
    return f"tw{float(tw):g}".replace(".", "p")


# ------------------------- dataset discovery -------------------------
def find_root():
    cands = [DATASET_ROOT] if DATASET_ROOT else ["/kaggle/input", "."]
    for base in cands:
        for dp, dns, _ in os.walk(base):
            if dp[len(base):].count(os.sep) > 4:
                dns[:] = []
                continue
            if "original" in dns and ("extra" in dns or "variants" in dns):
                return dp
    raise FileNotFoundError("Could not find the folder containing original/ extra/ mix/ variants/. "
                            "Set DATASET_ROOT explicitly.")


def find_files(d):
    out = {}
    for stem in FILE_STEMS:
        c = sorted(f for f in os.listdir(d) if f.lower().startswith(stem + "."))
        c.sort(key=lambda f: (not f.lower().endswith(".csv"), f))      # prefer plain .csv
        out[stem] = os.path.join(d, c[0]) if c else None
    return out


def classes_in(text):
    t = text.lower()
    t2 = re.sub(r"[^a-z0-9]", "", t)
    return [c for c in CLASSES if any(a in t or a in t2 for a in ALIASES[c])]


def discover(root):
    rows, problems = [], []
    for dp, _, fns in os.walk(root):
        if not any(f.lower().startswith("ata_write.") for f in fns):
            continue                                   # same rule as the repo's list-contents.sh
        parts = os.path.relpath(dp, root).split(os.sep)
        if len(parts) < 4 or parts[0] not in GROUPS:
            problems.append(f"unexpected location: {dp}")
            continue
        group, cpu, ram, rest = parts[0], parts[1], parts[2], "/".join(parts[3:])
        mm = re.match(r"ddr(\d)-(\d+)-(\d+)g", ram)
        hits = classes_in(rest)
        r = dict(group=group, cpu=cpu, ram=ram, rel_path="/".join(parts), leaf=rest,
                 ddr_gen=int(mm.group(1)) if mm else -1, ram_mhz=int(mm.group(2)) if mm else -1,
                 ram_gb=int(mm.group(3)) if mm else -1, mix_combo="", variant_tag="")
        if group in ("original", "extra"):
            if len(hits) != 1:
                problems.append(f"cannot map to ONE class ({hits}): {'/'.join(parts)}")
                continue
            r.update(class_name=hits[0])
        elif group == "variants":
            if hits != ["Conti"]:
                problems.append(f"variant folder not recognised as Conti ({hits}): {'/'.join(parts)}")
                continue
            r.update(class_name="Conti", variant_tag=rest)
        else:  # mix: exactly one of Conti/REvil + one or more benign apps
            ran = [h for h in hits if h in ("Conti", "REvil")]
            ben = sorted(h for h in hits if h in BENIGN)
            if len(ran) != 1 or not ben:
                problems.append(f"mix folder not parsed ({hits}): {'/'.join(parts)}")
                continue
            r.update(class_name=ran[0], mix_combo="+".join(ben) + "|" + ran[0])
        r["class_id"] = CLASSES.index(r["class_name"])
        r["y_bin"] = int(r["class_name"] in RANSOM)
        r["_dir"], r["_files"] = dp, find_files(dp)
        missing = [stem for stem, path in r["_files"].items() if path is None]
        r["missing_csvs"] = ";".join(missing)
        r["ata_read_missing"] = int(r["_files"]["ata_read"] is None)
        rows.append(r)
    meta = pd.DataFrame(rows)
    if meta.empty:
        raise RuntimeError("No execution folders found.\n" + "\n".join(problems[:20]))
    meta = meta.sort_values(["group", "cpu", "ram", "leaf"]).reset_index(drop=True)
    key = ["group", "cpu", "ram", "class_name", "mix_combo", "variant_tag"]
    meta["trial"] = meta.groupby(key).cumcount()
    return meta, problems


def validate(meta, problems):
    msgs = list(problems)

    # Directory counts are checked independently of CSV completeness.
    for g, exp in EXPECTED.items():
        got = int((meta.group == g).sum())
        if got != exp:
            msgs.append(f"{g}: found {got} execution folders, expected {exp}")

    # All 12 original classes should still have 120 execution directories.
    o = meta[meta.group == "original"]
    if len(o) and (o.groupby("class_name").size() != 120).any():
        msgs.append("original: class counts are not 120 each:\\n" +
                    o.class_name.value_counts().to_string())

    # Permit only the one independently verified missing file at its exact path.
    observed_missing = {}
    for _, row in meta.iterrows():
        missing = [stem for stem, path in row["_files"].items() if path is None]
        if missing:
            observed_missing[row["rel_path"]] = tuple(missing)

    if observed_missing != KNOWN_MISSING:
        msgs.append(
            "Unexpected missing-CSV pattern. Expected only "
            f"{KNOWN_MISSING}, but found {observed_missing}"
        )
    return msgs


# ------------------------- per-execution feature extraction -------------------------
@contextlib.contextmanager
def _open(path):
    if path.lower().endswith(".zip"):
        with zipfile.ZipFile(path) as zf:
            names = [n for n in zf.namelist() if not n.endswith("/")]
            names = [n for n in names if n.lower().endswith(".csv")] or names
            with zf.open(names[0]) as fh:
                yield fh
    else:
        yield path                                     # .csv / .csv.gz (pandas infers)


_COLS = ["ts", "tns", "addr", "size", "ent", "typ"]
_DT = {"ts": np.int64, "tns": np.int64, "addr": np.int64, "size": np.int64, "ent": np.float64, "typ": np.int64}


def _reader(fh, ncols, nrows=None, typed=True):
    names = _COLS[:ncols]
    return pd.read_csv(fh, header=None, usecols=list(range(ncols)), names=names, skipinitialspace=True,
                       dtype=_DT if typed else None, nrows=nrows,
                       chunksize=None if nrows else CHUNK_ROWS)


def _first_time(path):
    if path is None:
        return None
    try:
        with _open(path) as fh:
            df = _reader(fh, 2, nrows=1, typed=False).dropna()
        return int(df.ts.iloc[0]) * NS + int(df.tns.iloc[0]) if len(df) else None
    except pd.errors.EmptyDataError:
        return None


def _accumulate(path, t0, nb0, ncols):
    """Per-0.01 s-bin sufficient statistics of one CSV: n, sum(size), sum/sumsq of centred address,
    sum(entropy>=0), count(entropy>=0), counts of page types 1 (4KiB), 2 (2MiB), 4 (MMIO)."""
    keys = ("n", "size", "s1", "s2", "ent", "nent", "c1", "c2", "c4")
    acc = {k: np.zeros(nb0) for k in keys}
    if path is None or t0 is None:
        return acc
    limit, center = nb0 * BASE_NS, None
    for typed in (True, False):
        try:
            with _open(path) as fh:
                for ch in _reader(fh, ncols, typed=typed):
                    ch = ch.dropna()
                    t = ch["ts"].to_numpy(np.int64) * NS + ch["tns"].to_numpy(np.int64)
                    rel = t - t0
                    if rel.size == 0:
                        continue
                    k = (rel >= 0) & (rel < limit)
                    if k.any():
                        b = rel[k] // BASE_NS
                        a = ch["addr"].to_numpy(np.float64)[k]
                        center = float(a.mean()) if center is None else center
                        d = a - center
                        bc = lambda w=None, bb=b: np.bincount(bb, weights=w, minlength=nb0)
                        acc["n"] += bc()
                        acc["s1"] += bc(d)
                        acc["s2"] += bc(d * d)
                        acc["size"] += bc(ch["size"].to_numpy(np.float64)[k])
                        e = ch["ent"].to_numpy(np.float64)[k]
                        pos = e >= 0
                        acc["ent"] += np.bincount(b[pos], weights=e[pos], minlength=nb0)
                        acc["nent"] += np.bincount(b[pos], minlength=nb0)
                        if ncols == 6:
                            ty = ch["typ"].to_numpy(np.int64)[k]
                            for code, key in ((1, "c1"), (2, "c2"), (4, "c4")):
                                acc[key] += np.bincount(b[ty == code], minlength=nb0)
                    if rel.min() >= limit:             # files are time-ordered: nothing useful left
                        break
            return acc
        except pd.errors.EmptyDataError:
            return acc
        except ValueError:                             # dirty file: retry untyped + dropna
            acc = {k: np.zeros(nb0) for k in keys}
            center = None
    return acc


def _var(n, s1, s2):                                   # Eq. (2): unbiased variance, 0 if N < 2
    out = np.zeros_like(s1)
    ok = n >= 2
    out[ok] = (s2[ok] - s1[ok] ** 2 / n[ok]) / (n[ok] - 1)
    return np.maximum(out, 0.0)


def _mean(s, n):
    return np.divide(s, n, out=np.zeros_like(s), where=n > 0)


def extract_one(task):
    idx, files, plans, cache_path = task
    if os.path.exists(cache_path):
        z = np.load(cache_path, allow_pickle=False)
        return idx, {t: z[t] for t in z.files if t != "qc"}, json.loads(str(z["qc"]))
    nb0 = (_ns(TD_MAX)) // BASE_NS
    ft = {s: _first_time(files[s]) for s in FILE_STEMS}
    st = [v for s, v in ft.items() if s.startswith("ata") and v is not None]
    me = [v for s, v in ft.items() if s.startswith("mem") and v is not None]
    t0s, t0m = (min(st) if st else None), (min(me) if me else None)
    if TIME_ORIGIN == "common" and (st or me):
        t0s = t0m = min(st + me)
    S = {s: _accumulate(files[s], t0s if s.startswith("ata") else t0m, nb0, 5 if s.startswith("ata") else 6)
         for s in FILE_STEMS}
    out, qc = {}, {f"rows_{s}": int(S[s]["n"].sum()) for s in FILE_STEMS}
    for tw, p in plans.items():
        f, m, ns = p["f"], p["m"], p["n_steps"]

        def W(x):
            agg = x.reshape(-1, f).sum(1)
            if m == 1:
                return agg[:ns]
            cs = np.concatenate([[0.0], np.cumsum(agg)])
            return cs[m:m + ns] - cs[:ns]

        def V(a):
            return _var(W(a["n"]), W(a["s1"]), W(a["s2"]))

        r, w, mem = S["ata_read"], S["ata_write"], [S[k] for k in ("mem_read", "mem_write", "mem_readwrite", "mem_exec")]
        cols = [W(r["size"]) / tw, W(w["size"]) / tw, V(r), V(w), _mean(W(w["ent"]), W(w["nent"])),
                _mean(W(mem[1]["ent"]), W(mem[1]["nent"])), _mean(W(mem[2]["ent"]), W(mem[2]["nent"]))]
        for key in ("c1", "c2", "c4"):
            cols += [W(a[key]) for a in mem]
        cols += [V(a) for a in mem]
        X = np.stack(cols, 1).astype(np.float32)
        out[tw_tag(float(tw))] = X
        qc[f"zero_windows_{tw_tag(float(tw))}"] = float((~X.any(1)).mean())
        qc["has_nan_inf"] = int(qc.get("has_nan_inf", 0) or (not np.isfinite(X).all()))
    tmp = cache_path + ".tmp.npz"
    np.savez(tmp, qc=json.dumps(qc), **out)
    os.replace(tmp, cache_path)
    return idx, out, qc


# ------------------------- main pipeline -------------------------
def _split(meta, seed, frac):
    rng = np.random.default_rng(seed)
    o = meta.index[meta.group == "original"].to_numpy()
    tr, te = [], []
    for c in sorted(meta.loc[o, "class_id"].unique()):
        ids = rng.permutation(o[meta.loc[o, "class_id"].to_numpy() == c])
        k = int(round(len(ids) * frac))
        te += list(ids[:k]); tr += list(ids[k:])
    return np.sort(np.array(tr, dtype=np.int64)), np.sort(np.array(te, dtype=np.int64))


def main(**overrides):
    globals().update(overrides)
    t_start = time.time()
    os.makedirs(os.path.join(OUT_DIR, "cache"), exist_ok=True)
    root = find_root()
    print("Dataset root:", root)
    meta, problems = discover(root)
    print(meta.groupby("group").size().to_string(), "\n")
    for g in GROUPS:                                   # eyeball how folder names were parsed
        sub = meta[meta.group == g]
        if len(sub):
            print(f"[{g}] example folders:", *sub.rel_path.head(3), sep="\n   ")
            print(f"[{g}] classes:", sub.groupby("class_name").size().to_dict())
    msgs = validate(meta, problems)
    if msgs:
        print("\nVALIDATION ERRORS:\n - " + "\n - ".join(msgs[:25]))
        if STRICT:
            raise RuntimeError("Validation failed. Do not start extraction until the issue is resolved.")
    else:
        print("\nValidation passed.")
        for rel_path, stems in KNOWN_MISSING.items():
            print(f"Known exception retained: {rel_path} -> missing {', '.join(stems)}")
        print("Its T_s_r and V_s_r features will be zero placeholders, not observed zeros.")
        print("The sample is flagged with ata_read_missing=1 in metadata.")

    if VALIDATE_ONLY:
        print("\nVALIDATE_ONLY=True: validation finished; feature extraction was not started.")
        print("After reviewing the output, set VALIDATE_ONLY=False and rerun this script.")
        return meta

    plans = {float(tw): window_plan(float(tw), TD_MAX) for tw in T_WINDOWS}
    sig = json.dumps([sorted(plans), TD_MAX, TIME_ORIGIN, BASE_NS,
                      "v2_known_missing_ata_read_zero_flagged"])
    tasks = [(i, r["_files"], plans,
              os.path.join(OUT_DIR, "cache", hashlib.md5((r["rel_path"] + sig).encode()).hexdigest() + ".npz"))
             for i, r in meta.iterrows()]
    arrays = {tw_tw: np.zeros((len(meta), p["n_steps"], 23), np.float32)
              for tw_tw, p in ((tw_tag(tw), p) for tw, p in plans.items())}
    qcs = [None] * len(meta)
    try:
        from tqdm.auto import tqdm
    except Exception:
        tqdm = lambda x, **k: x
    with ProcessPoolExecutor(N_JOBS or os.cpu_count()) as ex:
        for idx, out, qc in tqdm(ex.map(extract_one, tasks, chunksize=2), total=len(tasks), desc="executions"):
            for tag, X in out.items():
                arrays[tag][idx] = X
            qcs[idx] = qc
    meta = pd.concat([meta, pd.DataFrame(qcs)], axis=1)
    meta["sample_id"] = np.arange(len(meta))
    drop = ["_dir", "_files"]
    for g in GROUPS:
        sel = np.flatnonzero((meta.group == g).to_numpy())
        if not len(sel):
            continue
        meta.iloc[sel].drop(columns=drop).reset_index(drop=True).to_csv(os.path.join(OUT_DIR, f"meta_{g}.csv"), index=False)
        for tag, A in arrays.items():
            np.save(os.path.join(OUT_DIR, f"X_{g}_{tag}.npy"), A[sel])
    o_idx = np.flatnonzero((meta.group == "original").to_numpy())
    if len(o_idx):
        tr, te = _split(meta.iloc[o_idx].reset_index(drop=True), SPLIT_SEED, TEST_FRACTION)
        np.savez(os.path.join(OUT_DIR, "split_original.npz"), train_idx=tr, test_idx=te)   # indices into X_original
    json.dump(dict(feature_names=FEATURE_NAMES, classes=CLASSES, ransomware=RANSOM, benign=BENIGN,
                   t_windows=[float(t) for t in T_WINDOWS], td_max=TD_MAX, time_origin=TIME_ORIGIN,
                   plans={tw_tag(k): {kk: int(vv) if kk != "tw" else vv for kk, vv in v.items()} for k, v in plans.items()}),
              open(os.path.join(OUT_DIR, "config.json"), "w"), indent=2)
    bad = int(meta["has_nan_inf"].sum())
    print(f"\nDone in {(time.time() - t_start) / 60:.1f} min. Outputs: {OUT_DIR}")
    print("executions with NaN/Inf:", bad, "| all-zero-window fraction (mean):",
          {c: round(float(meta[c].mean()), 3) for c in meta.columns if c.startswith('zero_windows')})
    return meta


# ------------------------- training-time loader -------------------------
def load_for_training(out_dir=OUT_DIR, t_window=0.1, td=30, feature_set="chi", task="binary",
                      train_idx=None, test_idx=None, log1p=False):
    """Baseline setup of the paper: group 'original', stratified 80/20 by execution.
    Returns float32 X [N, steps, F], standardised with statistics of the TRAIN part only.
    task: 'binary' (2 outputs) or 'multiclass' (12 outputs)."""
    tag = tw_tag(float(t_window))
    X = np.load(os.path.join(out_dir, f"X_original_{tag}.npy"))[:, :n_steps(t_window, td), FEATURE_SETS[feature_set]]
    meta = pd.read_csv(os.path.join(out_dir, "meta_original.csv"))
    if train_idx is None:
        sp = np.load(os.path.join(out_dir, "split_original.npz"))
        train_idx, test_idx = sp["train_idx"], sp["test_idx"]
    if log1p:
        X = np.log1p(X)
    mu = X[train_idx].reshape(-1, X.shape[-1]).mean(0)
    sd = X[train_idx].reshape(-1, X.shape[-1]).std(0)
    sd[sd < 1e-12] = 1.0
    X = ((X - mu) / sd).astype(np.float32)
    y = meta["y_bin"].to_numpy() if task == "binary" else meta["class_id"].to_numpy()
    k = 2 if task == "binary" else len(CLASSES)
    Y = np.eye(k, dtype=np.float32)[y]
    return dict(X_train=X[train_idx], Y_train=Y[train_idx], X_test=X[test_idx], Y_test=Y[test_idx],
                y_train=y[train_idx], y_test=y[test_idx], mean=mu, std=sd)


def standardise(X_fit, *others, log1p=False):
    """Use for every other experiment (6.2-6.5): fit on that experiment's TRAIN data only."""
    f = (lambda a: np.log1p(a)) if log1p else (lambda a: a)
    mu = f(X_fit).reshape(-1, X_fit.shape[-1]).mean(0)
    sd = f(X_fit).reshape(-1, X_fit.shape[-1]).std(0)
    sd[sd < 1e-12] = 1.0
    return [((f(a) - mu) / sd).astype(np.float32) for a in (X_fit, *others)]


if __name__ == "__main__":
    main()