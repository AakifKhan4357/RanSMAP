## Baseline Research and Documentation

The project includes the baseline research source code and supporting research documentation.

### Baseline Source Code (`baseline/`)

The `baseline/` directory contains the source code and master research notebook associated with the development and evaluation of the RanSMAP baseline CNN-LSTM model.

It includes:

- **Master research notebook (`baseline_master.ipynb`):** Documents dataset inspection, preprocessing validation, data split reconstruction, CNN-LSTM model development, training, evaluation, threshold analysis, and verification of the model artifacts used by the integrated application.
- **Preprocessing script (`ransmap_preprocessing_ready.py`):** Contains the preprocessing implementation used by the baseline research notebook.
- **README (`baseline/README.md`):** Provides information about the baseline research notebook, its purpose, artifact provenance and reproducibility limitations.

### Research Documentation (`RESEARCH_DOCUMENTATION.zip`)

The `RESEARCH_DOCUMENTATION.zip` archive is maintained at the project root and contains supporting research documents organized into six areas:

1. Research foundation
2. Preprocessing
3. Model and adaptation
4. Validation
5. Experimental results
6. Final evidence

These documents provide supporting information about the project's research methodology, implementation validation, experimental evaluation and evidence.

The notebook and research documentation serve as the research and artifact-provenance reference for the project. The integrated application does not execute these materials at runtime.

The trained model artifacts used during application inference are maintained separately under `backend/models/`, together with the corresponding model architecture and application implementation.